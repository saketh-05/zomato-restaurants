
function CuisineSearch() {
  return (
    <div>
      <h1>Cuisine Search</h1>
    </div>
  );
}

export default CuisineSearch;