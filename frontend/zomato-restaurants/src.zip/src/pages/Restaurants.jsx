
function Restaurants() {
  return (
    <div>
      <h1> Restaurants </h1>
    </div>
  );
}

export default Restaurants;