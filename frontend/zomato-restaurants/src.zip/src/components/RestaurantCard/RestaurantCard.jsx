import "./RestaurantCard.css";

function RestaurantCard(restaurantData){
    const myData = {
        "Restaurant Name": "Restaurant Name",
        "Aggregate rating": "Rating",
        "Rating text": "Rating Text",
        "Locality": "Locality"
    }
    restaurantData = myData;
    return(
        <div className='restaurant_card'>   
            <div className='restaurant_card_container'>
                <div className='restaurant_card_title'>
                    {restaurantData["Restaurant Name"]}
                </div>
                <div className='restaurant_card_rating'>
                    <div className='restaurant_card_rating_number'>
                        {restaurantData["Aggregate rating"]}
                    </div>
                    <div className='restaurant_card_rating_text'>
                        {restaurantData["Rating text"]}
                    </div>
                </div>
                <div className='restaurant_card_locality'>
                    {restaurantData["Locality"]}
                </div>
            </div>
        </div>
    )
}

export default RestaurantCard;