
function LocationSearch() {
  return (
    <div>
      <h1>Location Search</h1>
    </div>
  );
}

export default LocationSearch;