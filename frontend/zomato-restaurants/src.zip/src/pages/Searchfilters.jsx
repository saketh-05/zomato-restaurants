
function Searchfilters(){
    return(
        <div>
            <h1>Search Filters</h1>
        </div>
    )
}

export default Searchfilters;