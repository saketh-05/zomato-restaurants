
let apiUrl = "http://127.0.0.1:8000"

export default async function restaurantById(id){
    const response = await fetch(`${apiUrl}/restaurant/${id}`);
    const data = await response.json();
    if (response.status >= 400) {
        throw new Error(data.errors);
    }
    if(data.error) {
        throw new Error(data.error);
    }
    return data;
}    

export async function restaurantsList(page, limit) {
    const response = await fetch(`${apiUrl}/restaurants`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
        params: {
            page: page || 1,
            limit: limit || 10
        }
    });
    const data = await response.json();
    if (response.status >= 400) {
        throw new Error(data.errors);
    }
    if(data.error) {
        throw new Error(data.error);
    }
    return data;
}

export async function SearchByLocation(latitude, longitude, page, limit) {
    const response = await fetch(`${apiUrl}/restaurants/location`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
        params: {
            latitude: latitude,
            longitude: longitude,
            page: page || 1,
            limit: limit || 10
        }
    });
    const data = await response.json();
    if (response.status >= 400) {
        throw new Error(data.errors);
    }
    if(data.error) {
        throw new Error(data.error);
    }
    return data;
}

export async function SearchByCuisine(cuisine, page, limit) {
    const response = await fetch(`${apiUrl}/restuarants/cuisine`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
        params: {
            cuisine: cuisine,
            page: page || 1,
            limit: limit || 10
        }   
    });
    const data = await response.json();
    if (response.status >= 400) {
        throw new Error(data.errors);
    }
    if(data.error) {
        throw new Error(data.error);
    }
    return data;
}

