import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/home";
import LocationSearch from "./pages/locationSearch";
import Restaurants from "./pages/Restaurants";
import CuisineSearch from "./pages/CuisineSearch";
import Restaurant from "./pages/Restaurant";
import Navbar from "./components/Navbar/Navbar";
import Searchfilters from "./pages/Searchfilters";

function App() {
  return (
    <Router>
      <div className='App'>
        <Navbar />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/searchfilters' element={<Searchfilters />} />
          <Route path='/locationsearch' element={<LocationSearch />} />
          <Route path='/restaurants' element={<Restaurants />} />
          <Route path='/cuisinesearch' element={<CuisineSearch />} />
          <Route path='/restuarant/:id' element={<Restaurant />} />
          <Route path='*' element={<h1>Not Found</h1>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
