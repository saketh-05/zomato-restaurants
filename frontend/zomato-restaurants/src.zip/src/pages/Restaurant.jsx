
function Restaurant() {
  return (
    <div>
      <h1> Restaurant data </h1>
    </div>
  );
}

export default Restaurant;